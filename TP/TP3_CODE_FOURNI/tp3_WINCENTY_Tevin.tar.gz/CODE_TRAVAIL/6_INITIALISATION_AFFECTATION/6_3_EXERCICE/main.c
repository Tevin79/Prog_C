#include <stdio.h>
#include <stdlib.h>

// définir ici une constante non static (sans l'initialiser explicitement)
// définir ici une constante static (sans l'initialiser explicitement)

void f()
{
    // définir ici une constante static (sans l'initialiser explicitement)
    // définir ici une constante non static (sans l'initialiser)

    // essayez de changer ces deux constantes

    // afficher les deux constantes
}

int main()
{
    // définir ici une constante non static (sans l'initialiser)

    // afficher les 3 constantes visibles du main
    // essayez de changer ces trois constantes

    f();
    
    return EXIT_SUCCESS;
}
