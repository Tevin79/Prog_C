#ifndef OPERATION_H
#define OPERATION_H

extern int dummy;

int plus(int a, int b);
int moins(int a, int b);

int getNbOperations(void);

#endif
