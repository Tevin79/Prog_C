#include "fonction.c"

int main(void){
    f();
    g();
    return 0;
}

// g est impossible a appeler car elle est en static donc que definie dans fonctions.c
