# include <stdio.h>
void f(void){
    printf("Fonction non static\n");
}
static void g(void){
    printf("Fonction static\n");
}
