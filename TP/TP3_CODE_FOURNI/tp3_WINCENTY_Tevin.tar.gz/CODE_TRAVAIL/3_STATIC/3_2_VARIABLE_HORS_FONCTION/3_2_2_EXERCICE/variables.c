int g = 5;
static int s = 10;
