#!/bin/bash

gcc -g -Wall -Wextra -pedantic -std=c99 -o main main.c variables.c
