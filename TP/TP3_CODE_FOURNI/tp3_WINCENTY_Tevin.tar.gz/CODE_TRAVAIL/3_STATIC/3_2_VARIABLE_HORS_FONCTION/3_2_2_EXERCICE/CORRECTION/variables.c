//## cette variable est globale est accessible dans tous les .c du programme
int g = 3;

//## cette variable n'est utilisable que dans ce fichier (s'il y avait des fonctions)
static int s = 33;
