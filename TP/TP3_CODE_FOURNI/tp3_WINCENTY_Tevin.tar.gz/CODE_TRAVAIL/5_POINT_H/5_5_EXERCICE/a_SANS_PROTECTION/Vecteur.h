// pas de protections contre les doubles inclusions
// uniquement la structure
// ======== TODO ========
typedef struct vecteur{
    int x;
    int y;
    int z;
} vecteur;
