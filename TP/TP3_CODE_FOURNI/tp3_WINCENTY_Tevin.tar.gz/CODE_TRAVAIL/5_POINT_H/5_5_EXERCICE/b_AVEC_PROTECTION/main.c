#include "Vecteur.h"
#include "Repere.h"

int main(void)
{
    return 0;  // pas de EXIT_SUCCESS car on n'a pas "include <stdlib.h>"
}
