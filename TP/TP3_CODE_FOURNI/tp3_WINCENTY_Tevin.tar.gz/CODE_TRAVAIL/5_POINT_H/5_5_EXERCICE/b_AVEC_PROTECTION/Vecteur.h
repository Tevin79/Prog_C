// pas de protections contre les doubles inclusions
// uniquement la structure
// ======== TODO ========
#ifdef VECTEUR_H
#define VECTEUR_H

typedef struct vecteur{
    int x;
    int y;
    int z;
} vecteur;

#endif
