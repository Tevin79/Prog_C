#ifndef TITI_H
#define TITI_H

// car on utilise un type défini dans toto.h : myFloat


typedef int myInt;      // création d'un alias pour int

#include "toto.h"

void f(myFloat f);

#endif
