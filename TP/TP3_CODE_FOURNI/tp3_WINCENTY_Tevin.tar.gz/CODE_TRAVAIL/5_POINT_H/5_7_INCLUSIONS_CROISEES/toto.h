#ifndef TOTO_H
#define TOTO_H

// car on utilise un type défini dans titi.h : myInt


typedef float myFloat;      // création d'un alias pour float

#include "titi.h"

void g(myInt i);

#endif
