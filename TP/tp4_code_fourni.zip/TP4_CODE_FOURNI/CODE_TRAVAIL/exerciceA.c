#include <stdio.h>       // peut-être inutile
#include <stdlib.h>
#include <stdbool.h>     // peut-être inutile
#include <string.h>      // peut-être inutile
// inclure les .h nécessaires (cf. manuel)

int main()
{
    // avec open, dprintf et close, créer le fichier "FIC/exoA_1_test" et écrire l'entier 12 dedans
    
    // avec open, write et close, créer le fichier "FIC/exoA_2_test" et écrire l'entier 12 dedans

    // avec fopen, fprintf et fclose, créer le fichier "FIC/exoA_3_test" et écrire l'entier 12 dedans
    
    // avec fopen, fwrite et fclose, créer le fichier "FIC/exoA_4_test" et écrire l'entier 12 dedans
    
    return EXIT_SUCCESS;
}
